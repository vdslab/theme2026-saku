"""End-to-end layout comparisons through a shared centerline evaluator."""

from collections import Counter
from contextlib import ExitStack
from functools import wraps
import json
from math import hypot
import resource
import subprocess
import sys
from unittest.mock import patch

from torus_layout import pipeline
from torus_layout.layering import router
from torus_layout.models import PipelineConfig
from layout_common.cycle_removal import remove_cycles
from layout_common.hierarchy import insert_dummy_nodes
from sugiyama_layout import coordinate_assignment as planar_coordinates
from sugiyama_layout import crossing_reduction as planar_crossing
from sugiyama_layout.layer_assignment import assign_layers
from radial_layout import coordinate_assignment as radial_coordinates
from radial_layout import crossing_reduction as radial_crossing
from radial_layout.layer_assignment import assign_layers as assign_radial_layers
from radial_layout.drawing import _sample_chain

from .geometry import planar_route, route_metrics, torus_routes
from .stages import assignment_metrics, attempt_time, initialize, sift, subdivision_metrics


def measured_torus(graph, config=None):
    timings = {}

    def timed(owner, name):
        function = getattr(owner, name)

        @wraps(function)
        def wrapper(*args, **kwargs):
            result, elapsed = attempt_time(function, *args, **kwargs)
            timings[f"{name}_seconds"] = elapsed
            return result

        return patch.object(owner, name, wrapper)

    with ExitStack() as stack:
        for name in ("assign_layers", "insert_dummy_nodes", "reduce_crossings", "assign_coordinates"):
            stack.enter_context(timed(pipeline, name))
        for name in ("find_minimum_configuration", "balance_layers"):
            stack.enter_context(timed(router, name))
        result, elapsed = attempt_time(pipeline.run_pipeline, graph, config)
    return result, {**timings, "layout_seconds": elapsed}


def torus(graph, config=None, *, scaling=False):
    result, metrics = measured_torus(graph, config)
    if result is None:
        return {**metrics, "status": "no_solution"}, None
    metrics.update(assignment_metrics(graph, result.assignment, result.search.layer_count,
                                      result.search.torus_count))
    paths, subs = subdivision_metrics(graph, result.subdivided)
    metrics.update(subs)
    if metrics["assignment_violations"] or metrics["unit_span_violations"]:
        return {**metrics, "status": "invalid_layout"}, None
    if scaling:
        return metrics, result
    routes, bounds = torus_routes(paths, result.subdivided, result.crossing, result.coordinates)
    metrics["reverse_direction_edges"] = sum(
        any(b[0] < a[0] for a, b in zip(route.points, route.points[1:])) for route in routes
    )
    return {**metrics, **completed_metrics(routes, bounds)}, (routes, bounds)


def completed_metrics(routes, bounds=None, *, bends=True):
    metrics = route_metrics(routes, bounds, bends=bends)
    if bounds is None:
        width, height = metrics["centerline_bbox_width"], metrics["centerline_bbox_height"]
    else:
        width, height = bounds[2:]
    diagonal = hypot(width, height)
    if diagonal > 0:
        metrics["length_per_frame_diagonal"] = metrics["total_edge_length"] / diagonal
        metrics["max_length_per_frame_diagonal"] = metrics["max_edge_length"] / diagonal
        metrics["frame_aspect"] = width / height if height > 0 else None
    return metrics


def repository_baseline(graph, radial=False):
    def layout():
        acyclic = remove_cycles(graph.nodes, graph.edges)
        layout_edges = tuple(dict.fromkeys(acyclic.edges))
        layer_assignment = assign_radial_layers if radial else assign_layers
        ranks = layer_assignment(acyclic.nodes, layout_edges)
        proper = insert_dummy_nodes(acyclic.nodes, layout_edges, ranks)
        if radial:
            embedding = radial_crossing.reduce_crossings(proper.layers, proper.edges)
            positions = radial_coordinates.assign_coordinates(embedding.order)
        else:
            embedding = planar_crossing.reduce_crossings(proper.layers, proper.edges)
            positions = planar_coordinates.assign_coordinates(
                embedding, proper.edges, dummy_nodes=proper.dummy_nodes
            )
        return acyclic, proper, embedding, positions

    (acyclic, proper, embedding, positions), elapsed = attempt_time(layout)
    routes = []
    for edge in graph.edges:
        reverse = edge in acyclic.reversed_edges
        chain = proper.chains[edge[::-1] if reverse else edge]
        if radial:
            points = _sample_chain(chain, positions.polar, embedding.winding)
        else:
            points = [positions[u] for u in chain]
        routes.append(planar_route(edge, points[::-1] if reverse else points))
    return {
        "layout_seconds": elapsed, "layers": len(proper.layers),
        "dummy_nodes": len(proper.dummy_nodes), "proper_edges": len(proper.edges),
        "reverse_direction_edges": len(acyclic.reversed_edges),
        **completed_metrics(routes, bends=not radial),
    }, (routes, None)


def graphviz(graph, executable, timeout):
    # Graphviz IDs are generated from integer internal IDs, not source labels.
    flags = ("-Grankdir=LR", "-Gsplines=polyline", "-Tjson")
    source = "digraph {\n"
    source += "".join(f"n{u};\n" for u in graph.nodes)
    source += "".join(f"n{u} -> n{v};\n" for u, v in graph.edges) + "}\n"
    proc, elapsed = attempt_time(
        subprocess.run, [executable, *flags], input=source, encoding="utf-8",
        stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=timeout, check=True,
    )
    parsed = json.loads(proc.stdout)
    nodes = {obj["_gvid"]: (int(obj["name"][1:]), tuple(map(float, obj["pos"].split(","))))
             for obj in parsed["objects"]}
    routes = []
    reverse, same_rank = 0, 0
    for edge in parsed.get("edges", []):
        u, start = nodes[edge["tail"]]
        v, end = nodes[edge["head"]]
        reverse += end[0] < start[0]
        same_rank += end[0] == start[0]
        commands = [op for op in edge["_draw_"] if op["op"] in ("b", "B", "L")]
        if not commands:
            raise ValueError("missing Graphviz centerline")
        points = [start]
        corners = [start]
        for command in commands:
            control = [tuple(point) for point in command["points"]]
            if command["op"] == "L":
                points.extend(control)
                corners.extend(control)
                continue
            if (len(control) - 1) % 3:
                raise ValueError("unexpected Graphviz spline encoding")
            points.append(control[0])
            corners.extend(control[::3])
            for i in range(0, len(control) - 1, 3):
                a, b, c, d = control[i:i+4]
                for step in range(1, 17):
                    t = step / 16
                    s = 1 - t
                    points.append(tuple(s**3*w + 3*s*s*t*x + 3*s*t*t*y + t**3*z
                                        for w, x, y, z in zip(a, b, c, d)))
        points.append(end)
        corners.append(end)
        routes.append(planar_route((u, v), points, corners))
    if Counter(route.edge for route in routes) != Counter(graph.edges):
        raise ValueError("Graphviz changed edge set")
    return {"layout_seconds": elapsed, "reverse_direction_edges": reverse, "same_rank_edges": same_rank,
            **completed_metrics(routes)}, (routes, None)


def framework_study(graph, run, args):
    config = PipelineConfig(optimize_seams=False, unwind_levels=False)

    def cylindrical_reference():
        def fixed_winding(subdivided, rounds, **_kwargs):
            initial = initialize(subdivided, True)
            initial.winding_numbers.update(dict.fromkeys(subdivided.graph.edges, 0))
            return sift(subdivided, initial, rounds, winding=False)

        with patch.object(pipeline, "reduce_crossings", fixed_winding):
            return torus(graph, config)

    variants = {
        "torus": lambda: torus(graph),
        "sugiyama": lambda: repository_baseline(graph),
        "radial": lambda: repository_baseline(graph, radial=True),
        "dot": lambda: graphviz(graph, args.dot, args.comparison_seconds),
        "torus_without_unwind_or_dp": lambda: torus(graph, config),
        "cylindrical_reference": cylindrical_reference,
    }
    run("framework", args.variant, args.baseline, variants[args.variant])


def scaling_study(graph, run):
    def evaluate():
        metrics, layout = torus(graph, scaling=True)
        rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        metrics["peak_process_mib"] = rss / (1024**2 if sys.platform == "darwin" else 1024)
        return metrics, layout
    run("scaling", "torus", "torus", evaluate)
